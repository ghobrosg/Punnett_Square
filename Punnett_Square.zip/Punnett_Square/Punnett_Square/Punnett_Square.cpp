// Punnett_Square.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    cout << "Welcome to the Punnett Square solver, please enter the first allele of the first parent:" << endl;
    string dominant1;
    string recessive1;
    string dominant2;
    string recessive2;
    cin >> dominant1;
    cout << "Now enter the second allele of the first parent" << endl;
    cin >> recessive1;
    cout << "Now enter the first allele of the second parent" << endl;
    cin >> dominant2;
    cout << "Now enter the second allele of the second parent" << endl;
    cin >> recessive2;

    string A = dominant1 + dominant2;
    string B = recessive1 + dominant2;
    string C = dominant1 + recessive2;
    string D = recessive1 + recessive2;

    cout << "Here are the results of your input" << endl;
    cout << setw(10) << "" << setw(15) << "" << setw(10) << dominant1 + " |" << setw(10) << recessive1 + "|" << endl;
    cout << setw(10) << "" << setw(15) << "" << setw(10) << "----------" << setw(10) << "----------" << endl;
    cout << setw(10) << "" << setw(15) << dominant2 + " |" << setw(10) << A + "|" << setw(10) << B + "|" << endl;
    cout << setw(10) << "" << setw(15) << "" << setw(10) << "----------" << setw(10) << "----------" << endl;
    cout << setw(10) << "" << setw(15) << recessive2 + " |" << setw(10) << C +"|" << setw(10) << D + "|" << endl;
    system("pause");
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
